chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.toggleTaskVisibility !== undefined) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
        sendResponse(response);
      });
    });
    return true; // Nødvendigt for asynkron sendResponse
  }
});
