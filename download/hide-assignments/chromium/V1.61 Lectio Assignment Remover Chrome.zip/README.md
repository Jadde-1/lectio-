Lectio Fraværsdiagram - Installationsguide

Denne udvidelse er designet til at hjælpe med at visualisere fraværsdata på Lectio-platformen.

Følg disse enkle trin for at installere udvidelsen i din browser (Firefox eller Chrome):
Installationsvejledning til Firefox

   1. Download .xpi-filen til din computer (den fil, du har modtaget).

   2. Åbn Firefox.

   3. Klik på de tre horisontale linjer i øverste højre hjørne (menuknappen) og vælg Tilføjelser.

   4. I venstre menu, vælg Udvidelser.

   5. Klik på knappen Installer fra fil (under menuen med gearikonet).

   6. Find og vælg den downloadede .xpi-fil.

   7. Bekræft installationen, og udvidelsen vil blive installeret.

   8. Når installationen er afsluttet, vil udvidelsen være aktiv og klar til brug!

Installationsvejledning til Chrome

   1. Download .zip-filen (den fil, du har modtaget) og pak den ud til en mappe på din computer.

   2. Åbn Chrome.

   3. Gå til chrome://extensions i din browser (eller klik på de tre prikker i øverste højre hjørne og
      vælg "Flere værktøjer" → "Udvidelser").

   4. Slå Udviklertilstand til (tænd for knappen i øverste højre hjørne).

   5. Klik på knappen Indlæs udpakket.

   6. Find og vælg den mappe, hvor du pakkede udvidelsen (den skal indeholde en manifest.json-fil).

   7. Når du har valgt mappen, vil udvidelsen blive installeret og klar til brug!