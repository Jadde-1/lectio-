console.log("Lectio Extension: Fravær er indlæst!");

// Hent alle rækker
const rows = document.querySelectorAll('tr');

// Filtrer rækken "Samlet" ud
const filteredRows = Array.from(rows).filter(row => {
    const cells = row.querySelectorAll('td');
    if (cells.length > 2) {
        const name = cells[0].textContent.trim();
        return name !== "Samlet";  // Udeluk rækken med "Samlet"
    }
    return true;  // Behold alle andre rækker
});

// Funktion til at udtrække fraværsdata
const extractAbsenceData = (index) => {
    return filteredRows
        .map(row => {
            const cells = row.querySelectorAll('td');
            
            if (cells.length > index) {
                const absenceText = cells[index].textContent.trim();  // Vi ser på det givne index
                const match = absenceText.match(/^(\d+)\/(\d+)$/);  // Matcher formatet "X/Y"
                
                if (match) {
                    const absent = parseInt(match[1]);  // Fraværende moduler
                    const total = parseInt(match[2]);   // Totalt antal moduler
                    
                    // Beregn procent, hvis total er større end 0
                    const percentage = total > 0 ? (absent / total) * 100 : 0;

                    if (percentage === 0 && index === 2) {  // Hvis fravær er 0
                        return { name: 'Ukendt', absent: 0, total: total };
                    }

                    const name = cells[0].querySelector('a') ? cells[0].querySelector('a').textContent.trim() : 'Ukendt';

                    return {
                        name: name,
                        percentage: percentage,
                        absent: absent,
                        total: total
                    };
                }
            }
            return null;
        })
        .filter(data => data !== null);  // Filtrér null-værdier
};

// Hent data for fravær (index 2) og skriftligt fravær (index 1)
const absenceData = extractAbsenceData(2);  // Fravær
const writtenAbsenceData = extractAbsenceData(1);  // Skiftet til index 1 for skriftligt fravær

console.log("Fraværsdata:", absenceData);
console.log("Skriftligt Fraværsdata:", writtenAbsenceData);

// Beregn total fravær og moduler for fravær
const totalAbsence = absenceData.reduce((acc, data) => acc + data.absent, 0);
const totalModules = absenceData.reduce((acc, data) => acc + data.total, 0);
const totalPercentage = totalModules > 0 ? (totalAbsence / totalModules) * 100 : 0;

// Beregn total skriftligt fravær og moduler
const totalWrittenAbsence = writtenAbsenceData.reduce((acc, data) => acc + data.absent, 0);
const totalWrittenModules = writtenAbsenceData.reduce((acc, data) => acc + data.total, 0);
const totalWrittenPercentage = totalWrittenModules > 0 ? (totalWrittenAbsence / totalWrittenModules) * 100 : 0;

// Erstat billede med diagrammet i den ønskede div
const divContainer = document.querySelector('div[style="overflow-x: auto; max-width: inherit;"]');  // Find <div>
const image = divContainer.querySelector('img');  // Find billede i div
if (image) {
    image.remove();  // Fjern billedet
}

// Opret en container for fraværs-sektionen
const absenceSection = document.createElement('div');
absenceSection.style.width = '50%';  // Hele bredden for fravær
divContainer.appendChild(absenceSection);

// Opret en overskrift for fravær
const header = document.createElement('h3');
header.textContent = "Fysik Fravær";  // Overskriften for fravær
absenceSection.appendChild(header);

// Opret en underoverskrift for fravær med total fravær og moduler
const subHeader = document.createElement('h4');
subHeader.textContent = `Total Fravær: ${totalPercentage.toFixed(2)}% (${totalAbsence}/${totalModules} moduler)`;
absenceSection.appendChild(subHeader);

const canvas = document.createElement('canvas');
canvas.id = 'lectioChart';
canvas.style.position = 'relative';
canvas.style.width = '100%';
canvas.style.height = '300px';
absenceSection.appendChild(canvas);

// Brug Chart.js til fravær
const ctx = canvas.getContext('2d');
new Chart(ctx, {
    type: 'pie',
    data: {
        labels: absenceData.filter(item => item.absent > 0).map(item => item.name),  // Kun vis navne med fravær
        datasets: [{
            data: absenceData.filter(item => item.absent > 0).map(item => item.percentage),  // Brug procentdelen for diagrammet
            backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56', '#4bc0c0', '#9966ff', '#ff9f40'],
        }]
    },
    options: {
        responsive: false,
        plugins: {
            legend: {
                position: 'bottom',
            }
        }
    }
});

// Opret en container for skriftligt fravær-sektionen
const writtenSection = document.createElement('div');
writtenSection.style.width = '50%';  // Hele bredden for skriftligt fravær
divContainer.appendChild(writtenSection);

// Opret en overskrift for skriftligt fravær
const headerWritten = document.createElement('h3');
headerWritten.textContent = "Skriftligt Fravær";  // Overskriften for skriftligt fravær
writtenSection.appendChild(headerWritten);

// Opret en underoverskrift for skriftligt fravær med total fravær og moduler
const subHeaderWritten = document.createElement('h4');
subHeaderWritten.textContent = `Total Fravær: ${totalWrittenPercentage.toFixed(2)}% (${totalWrittenAbsence}/${totalWrittenModules} moduler)`;
writtenSection.appendChild(subHeaderWritten);

const writtenCanvas = document.createElement('canvas');
writtenCanvas.id = 'lectioChartWritten';
writtenCanvas.style.position = 'relative';
writtenCanvas.style.width = '100%';
writtenCanvas.style.height = '300px';
writtenSection.appendChild(writtenCanvas);

// Brug Chart.js til skriftligt fravær
const ctxWritten = writtenCanvas.getContext('2d');
new Chart(ctxWritten, {
    type: 'pie',
    data: {
        labels: writtenAbsenceData.filter(item => item.absent > 0).map(item => item.name),
        datasets: [{
            data: writtenAbsenceData.filter(item => item.absent > 0).map(item => item.percentage),
            backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56', '#4bc0c0', '#9966ff', '#ff9f40'],
        }]
    },
    options: {
        responsive: false,
        plugins: {
            legend: {
                position: 'bottom',
            }
        }
    }
});
