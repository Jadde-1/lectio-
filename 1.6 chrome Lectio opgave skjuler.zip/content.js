// Skjul opgaver, der ikke venter
function hideTasks() {
    let taskRows = document.querySelectorAll('tr:not(:first-child)');
    taskRows.forEach(row => {
        let statusCell = row.querySelector('.textCenter.OnlyDesktop');
        if (statusCell && statusCell.innerText.trim() !== 'Venter') {
            row.style.display = 'none';
        } else {
            let weekCell = row.querySelector('.OnlyDesktop [title^="Uge"]');
            if (weekCell) {
                weekCell.closest('td').style.display = 'table-cell';
                weekCell.innerText = '';
            }
        }
    });
  }
  
  // Vis alle opgaver
  function showAllTasks() {
    let allTaskRows = document.querySelectorAll('tr');
    allTaskRows.forEach(row => {
        row.style.display = 'table-row';
    });
  }
  
  // Lyt til beskeder fra popup.js
  chrome.runtime.onMessage.addListener((message) => {
    if (message.toggleTaskVisibility !== undefined) {
        if (message.toggleTaskVisibility) {
            showAllTasks();
        } else {
            hideTasks();
        }
    }
  });
  
  // Skjul opgaver som standard
  hideTasks();
  