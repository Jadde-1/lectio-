document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggleTasksButton');
    const statusMessage = document.getElementById('statusMessage');

    // Kontroller, om brugeren er på Lectio
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const url = tabs[0].url;
        if (url && url.includes("lectio.dk")) {
            toggleButton.disabled = false;
            statusMessage.textContent = ""; // Fjern statusmeddelelse
            setupToggleButton(toggleButton);
        } else {
            toggleButton.disabled = true;
            statusMessage.textContent = "Du skal være på Lectio for at bruge denne funktion.";
        }
    });
});

function setupToggleButton(button) {
    // Hent status fra Local Storage
    chrome.storage.local.get('taskVisibility', (data) => {
        const isTaskVisible = data.taskVisibility || false;
        updateButtonState(button, isTaskVisible);
    });

    // Klik-event for knappen
    button.addEventListener('click', () => {
        chrome.storage.local.get('taskVisibility', (data) => {
            const isTaskVisible = data.taskVisibility || false;
            const newVisibility = !isTaskVisible;

            // Send besked til content script
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                chrome.tabs.sendMessage(tabs[0].id, { toggleTaskVisibility: newVisibility });
            });

            // Opdater status
            chrome.storage.local.set({ taskVisibility: newVisibility });
            updateButtonState(button, newVisibility);
        });
    });
}

function updateButtonState(button, isTaskVisible) {
    button.textContent = isTaskVisible ? "Skjul Opgaver" : "Vis Opgaver";
    if (isTaskVisible) {
        button.classList.add("faded"); // Fad knappen ud
    } else {
        button.classList.remove("faded"); // Fjern fading
    }
}
