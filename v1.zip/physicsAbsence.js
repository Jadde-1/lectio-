// Function to hide the existing image
const hideExistingImage = () => {
    const image = document.querySelector('#s_m_Content_Content_SFTabAbsenceimg');
    if (image) {
        image.style.display = 'none'; // Hides the image
    }
};

// Function to set up the charts side by side
const setupChartsSideBySide = () => {
    const contentDiv = document.querySelector('#s_m_Content_Content_SFTabGraphicViewIsland_pa');
    if (contentDiv) {
        contentDiv.style.display = 'flex'; // Use flexbox for horizontal layout
        contentDiv.style.justifyContent = 'space-between';  // Distribute charts evenly across available space
        contentDiv.style.flexWrap = 'wrap';  // Allow wrapping on smaller screens
        contentDiv.style.padding = '20px';  // Optional: Add some padding around the charts
    }
};

// Function to extract absence data
const extractAbsenceData = (rows, columnIndex) => {
    let totalModules = 0;  // To accumulate the total number of modules
    let totalAbsent = 0;   // To accumulate the total number of absences

    const data = rows
        .map(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length > columnIndex) {
                const absenceText = cells[columnIndex].textContent.trim();
                const match = absenceText.match(/^(\d+)\/(\d+)$/); // Match format like "X/Y"
                if (match) {
                    const absent = parseInt(match[1]); // First number (absent)
                    const total = parseInt(match[2]);  // Second number (total)
                    
                    // Ensure that if "0/XX" exists, it still counts towards total modules
                    totalAbsent += absent;             // Accumulate total absences
                    totalModules += total;             // Accumulate total modules
                    const percentage = total > 0 ? (absent / total) * 100 : 0;
                    const name = cells[0].querySelector('a')
                        ? cells[0].querySelector('a').textContent.trim()
                        : "Unknown";
                    return { name, percentage, absent, total };
                }
            }
            return null;
        })
        .filter(data => data !== null); // Filter out any rows that do not have valid data

    // Fallback to "100% Stræber" if all data is 0/n
    if (totalAbsent === 0 && totalModules > 0) {
        return [{ name: "Stræber", percentage: 100, absent: 0, total: totalModules }];
    }

    // Return data or fallback
    return data.length > 0 ? data : [{ name: "Stræber", percentage: 100, absent: 0, total: totalModules }];
};

// Function to create the chart
const createChart = (container, title, data, totalAbsent, totalModules) => {
    const section = document.createElement('div');
    section.style.margin = '20px';
    section.style.padding = '10px';
    section.style.border = '1px solid #ccc';
    section.style.borderRadius = '8px';
    section.style.backgroundColor = '#f9f9f9';
    section.style.flex = '1';  // Allow charts to grow and shrink equally
    section.style.maxWidth = '45%';  // Ensure charts have a maximum width for a side-by-side layout
    section.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
    container.appendChild(section);

    const header = document.createElement('h3');
    header.textContent = title;
    header.style.textAlign = 'center';
    section.appendChild(header);

    const subHeader = document.createElement('h4');
    const totalPercentage = totalModules > 0 ? (totalAbsent / totalModules) * 100 : 0;
    subHeader.textContent = `Total Fravær: ${totalPercentage.toFixed(2)}% (${totalAbsent}/${totalModules} moduler)`;
    subHeader.style.textAlign = 'center';
    section.appendChild(subHeader);

    const canvas = document.createElement('canvas');
    canvas.style.position = 'relative';
    canvas.style.width = '100%';
    canvas.style.height = '300px';
    section.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(item => item.name),
            datasets: [{
                data: data.map(item => item.percentage),
                backgroundColor: ['#ff6384', '#36a2eb', '#ffcd56', '#4bc0c0', '#9966ff', '#ff9f40'],
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
};

// Get all rows and exclude the "Samlet" row
const rows = Array.from(document.querySelectorAll('tr')).filter(row => {
    const cells = row.querySelectorAll('td');
    return !(cells.length > 2 && cells[0].textContent.trim() === "Samlet");
});

// Hide the image and set up charts side by side
hideExistingImage();
setupChartsSideBySide();

// Add charts to the body
const body = document.querySelector('#s_m_Content_Content_SFTabGraphicViewIsland_pa');

// Physics absence (column 3, index 2)
const fysikData = extractAbsenceData(rows, 2);
const totalFysikAbsent = fysikData.reduce((acc, data) => acc + data.absent, 0);
const totalFysikModules = fysikData.reduce((acc, data) => acc + data.total, 0);
createChart(body, "Fysik Fravær", fysikData, totalFysikAbsent, totalFysikModules);

// Written absence (column 7, index 6)
const writtenData = extractAbsenceData(rows, 6); // Update this index if necessary
const totalWrittenAbsent = writtenData.reduce((acc, data) => acc + data.absent, 0);
const totalWrittenModules = writtenData.reduce((acc, data) => acc + data.total, 0);
createChart(body, "Skriftligt Fravær", writtenData, totalWrittenAbsent, totalWrittenModules);
